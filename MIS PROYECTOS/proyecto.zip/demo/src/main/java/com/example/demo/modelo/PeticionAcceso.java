package com.example.demo.modelo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PeticionAcceso {
    String correo;
    String contraseña;
}
